﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class BarrelDestroyer : MonoBehaviour {

	void OnTriggerEnter2D (Collider2D other){
		if (other.CompareTag ("barrel")) {
			Debug.Log ("hitOilBarrel");
			Destroy (other.gameObject);
		}

	}
}

﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class Menu: MonoBehaviour {
	public int cursorAwake;
	public GameObject aCursor; 
	public GameObject bCursor; 
	void Start(){
		aCursor = GameObject.Find ("cursor");
		bCursor = GameObject.Find ("cursor2");
		aCursor.SetActive (true);
		bCursor.SetActive (false);
		cursorAwake = 0;
	}

	void Update (){
		if (Input.GetKeyDown("down")){
			if (cursorAwake == 0) {
				bCursor.SetActive (true);
				aCursor.SetActive (false);
				cursorAwake = 1;
			} else if (cursorAwake == 1) {
				bCursor.SetActive (false);
				aCursor.SetActive (true);
				cursorAwake = 0;
			}
		}
		if (Input.GetKeyDown("up")){
			if (cursorAwake == 0) {
				bCursor.SetActive (true);
				aCursor.SetActive (false);
				cursorAwake = 1;
			} else if (cursorAwake == 1) {
				bCursor.SetActive (false);
				aCursor.SetActive (true);
				cursorAwake = 0;
			}
		}
		if (Input.GetKeyDown ("return")) {
			if (cursorAwake == 0) {
				PlayGame ();
			} else if (cursorAwake == 1) {
				LevelTwo ();
			}
		}
	}

	// Use this for initialization
	public void PlayGame (){
		SceneManager.LoadScene ("Scenes/level1");
	}
	public void LevelTwo (){
		SceneManager.LoadScene ("Scenes/level2");
	}
}
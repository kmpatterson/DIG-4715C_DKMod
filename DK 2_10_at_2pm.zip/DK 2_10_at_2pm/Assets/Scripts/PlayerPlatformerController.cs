﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class PlayerPlatformerController : PhysicsObject {

	public float maxSpeed = 3;
	public float jumpTakeOffSpeed = 7;
	public int direction = 1;
	public Vector2 move = Vector2.zero;


	protected override void UpdateClimb(){
		if (isClimbing == true) {
			//this is up
			if (Input.GetAxis ("Vertical") > 0) {
				//turn off gravity
				gravityModifier = 0;
				//move up the ladder at a slow pace
				transform.Translate (0, .03f, 0);
				SendMessage ("onClimb", SendMessageOptions.DontRequireReceiver);
				animator.SetBool ("playerClimb", true);
			}
			//this is down
			else if (Input.GetAxis ("Vertical") < 0) {
				gravityModifier = 0;
				transform.Translate (0, -.03f, 0);
				animator.SetBool ("playerClimb", true);
				SendMessage ("onClimb", SendMessageOptions.DontRequireReceiver);
			}else if (Input.GetAxis ("Vertical") == 0 ){
				animator.SetBool ("playerClimb", true);
		}
	}
	}

	protected override void UpdateJump(){
		//Jumping

		if (Input.GetButtonDown ("Jump")) {
			velocity.y = jumpTakeOffSpeed;
			animator.SetBool ("playerJump", true);
		} else if (Input.GetButtonUp ("Jump")) 
		{
			if (velocity.y > 0) {
				animator.SetBool ("playerJump", true);
				velocity.y = velocity.y * 0.5f;
			}
		}


		if (grounded == true) {
			move.x = Input.GetAxis ("Horizontal");
			animator.SetBool ("playerJump", false);

		} else if (isJumping) {
			if (direction == 1) {
				transform.Translate (1.5f, 0, 0);
			}
			if (direction == 0) {
				transform.Translate (-1.5f, 0, 0);
			}
		}

	}

	protected override void ComputeVelocity()
	{
		//Horizontal Movement

		if ((Mathf.Abs (move.x) > 0f)) {
			animator.SetBool ("isMoving", true);
			animator.SetBool ("playerIdle", false);
		} else {
			animator.SetBool ("isMoving", false);

		}


		//sprite flipper
		//implement flipping stop mid jump
		if (animator.GetBool ("playerJump") == false) {
			if (Input.GetAxis ("Horizontal") < 0) {
				spriteRenderer.flipX = false;
				direction = 0;
			} else if (Input.GetAxis ("Horizontal") > 0) {
				spriteRenderer.flipX = true;
				direction = 1;
			}
		}
		animator.SetFloat ("velocityX", Mathf.Abs (velocity.x) / maxSpeed);

		if (Mathf.Abs (move.x) > 0){
			if (move.x > 0 ){
				move.x = 1;
				targetVelocity = move * maxSpeed;
			}else if(move.x < 0){
				move.x = -1;
				targetVelocity = move * maxSpeed;
			}


		}
		//if character isn't idle set trigger playerWalk
		if (targetVelocity != Vector2.zero && grounded == true) {
			animator.SetTrigger ("isMoving");
		}
	}
}

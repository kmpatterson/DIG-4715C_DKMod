﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using UnityEngine.SceneManagement;

public class PhysicsObject : MonoBehaviour {

	public float minGroundNormalY = .65f;
	public float gravityModifier = 0.75f;
	public float maxSpeed = 3;
	public float jumpUp = 0.08f;
	public int direction = 1;
	public Vector2 move = Vector2.zero;
	public float jumpTime = .12f;
	public float laserTime = 24;
	public float jumpX = 0.04f;

	//states
	public bool isJumping;
	public bool isClimbing;
	public bool canClimb;
	public bool isMoving;
	public bool isGrounded = true;
	public bool isIdle;
	public bool isDead;
	public bool isMantle;
	public bool canUp;
	public bool canDown;
	public bool canJump;
	public bool isLaser;
	public bool canRight = true;
	public bool canLeft = true;


	protected Vector2 targetVelocity;

	protected Vector2 groundNormal;
	protected Rigidbody2D rb2d;
	protected Vector2 velocity;
	protected ContactFilter2D contactFilter;
	protected RaycastHit2D[] hitBuffer = new RaycastHit2D[16];
	protected List<RaycastHit2D> hitBufferList = new List<RaycastHit2D> (16);

	protected const float minMoveDistance = 0.001f;
	protected const float shellRadius = 0.01f;

	//animation
	protected SpriteRenderer spriteRenderer;
	protected Animator animator;

	// Use this for initialization
	void Awake () 
	{
		spriteRenderer = GetComponent<SpriteRenderer> (); 
		animator = GetComponent<Animator> ();
	}

	void OnEnable()
	{
		rb2d = GetComponent<Rigidbody2D> ();
	}

	void Start () 
	{
		contactFilter.useTriggers = false;
		contactFilter.SetLayerMask (Physics2D.GetLayerCollisionMask (gameObject.layer));
		contactFilter.useLayerMask = true;
	}

	void Update () 
	{
		targetVelocity = Vector2.zero;
		ComputeVelocity (); 
		UpdateClimb ();


		if (isJumping == true) {
			animator.SetBool ("isJumping", true);
		} else {
			animator.SetBool ("isJumping", false);
		}
		if (isClimbing == true){
			animator.SetBool ("isClimbing", true);
		} else {
			animator.SetBool ("isClimbing", false);
		}
		if (isMoving == true){
			animator.SetBool ("isMoving", true);
		} else {
			animator.SetBool ("isMoving", false);
		}
		if (isGrounded == true){
			animator.SetBool ("isGrounded", true);
		} else {
			animator.SetBool ("isGrounded", false);
		}
		if (isIdle == true){
			animator.SetBool ("isIdle", true);
		} else {
			animator.SetBool ("isIdle", false);
		}
		if (isDead == true){
			animator.SetBool ("isDead", true);
		} else {
			animator.SetBool ("isDead", false);
		}
		if (isMantle == true){
			animator.SetBool ("isMantle", true);
		} else {
			animator.SetBool ("isMantle", false);
		}
	}



	public void ComputeVelocity()
	{

		//Horizontal Movement
		if ((Mathf.Abs (move.x) > 0f)) {
			isMoving = true;
			isIdle = false;
		} else {
			isMoving = false;
			isIdle = true;
		}

		if (Mathf.Abs (move.x) > 0){
			if (canRight == true) {
				if (move.x > 0) {
					move.x = 1;
					targetVelocity = move * maxSpeed;
				}
			}
			if (canLeft == true) {
				if (move.x < 0) {
					move.x = -1;
					targetVelocity = move * maxSpeed;
				}
			}

		//sprite flipper
		//implement flipping stop mid jump
		if (isJumping == false) {
			if (Input.GetAxis ("Horizontal") < 0) {
				spriteRenderer.flipX = false;
				direction = 0;
			} else if (Input.GetAxis ("Horizontal") > 0) {
				spriteRenderer.flipX = true;
				direction = 1;
			}
		}
		animator.SetFloat ("velocityX", Mathf.Abs (velocity.x) / maxSpeed);



		}
		move.x = 0f;
	}

	void FixedUpdate()
	{
		if (isJumping == false && isDead == false) {
			if (Input.GetKey ("right")) {
				
				goRight ();
			} else if (Input.GetKey ("d")) {
				goRight ();
			}
			if (Input.GetKey ("left")) {
				
				goLeft ();
			} else if (Input.GetKey ("a")) {
				goLeft ();
			}
		}

		if (isGrounded == true && Input.GetButton ("Jump") && canJump == true && isLaser == false) {
			isJumping = true;
			if (isMoving == true) {
				StartCoroutine ("MovingJump");
			} else {
				StartCoroutine ("Jumping");
			}
		}


		velocity += gravityModifier * Physics2D.gravity * Time.deltaTime;
		velocity.x = targetVelocity.x;

		Vector2 deltaPosition = velocity * Time.deltaTime;

		Vector2 moveAlongGround = new Vector2 (groundNormal.y, -groundNormal.x);

		Vector2 move = moveAlongGround * deltaPosition.x;

		Movement (move, false);

		move = Vector2.up * deltaPosition.y;

		Movement (move, true);
	}


	IEnumerator Jumping (){
		//Set the gravity to zero and apply the force once
		gravityModifier = 0f;
		float timer = 0f;
		while (timer < jumpTime) {
			timer += Time.deltaTime;
			transform.Translate (0, jumpUp, 0);
			yield return null;
		}
		//Set Gravity back to normal at the end of the jump
		gravityModifier = 0.75f;
	}

	IEnumerator MovingJump (){
		//Set the gravity to zero and translate up and direction
		gravityModifier = 0f;
		float timer = 0f;

		while (timer < jumpTime) {
			if (direction == 1) {
				transform.Translate (jumpX, jumpUp, 0);
			} else if (direction == 0) {
				transform.Translate ((-1 *jumpX), jumpUp, 0);
			}


			timer += Time.deltaTime;

		yield return null;
		}
		//Set Gravity back to normal at the end of the jump
		gravityModifier = 0.75f;
	}

	public void goRight(){
		move.x = 1;
	}
	public void goLeft(){
		move.x = -1;
	}

	public void UpdateClimb(){
		if (isJumping == false && isDead == false) {
			if (canClimb == true) {
				//this is up
				if (canUp == true) {
					if (Input.GetAxis ("Vertical") > 0) {
						//move up the ladder at a slow pace
						gravityModifier = 0f;
						transform.Translate (0, .03f, 0);
						isClimbing = true;
						canJump = false;
						canLeft = false;
						canRight = false;
					}
				}
				//this is down
				if (canDown == true) {
					if (Input.GetAxis ("Vertical") < 0) {
						gravityModifier = 0f;
						transform.Translate (0, -.03f, 0);
						isClimbing = true;
						canJump = false;
						canLeft = false;
						canRight = false;
					}
				}
			}
		}
	}

	//enter the trigger
	public void OnTriggerEnter2D (Collider2D col)
	{

		if (col.gameObject.tag == "barrel") {
			isDead = true;
			StartCoroutine(Death());
		}

		if (col.gameObject.tag == "Catnip") {
			Destroy (col.gameObject);
			StartCoroutine (Laser ());
		}

		if (col.gameObject.tag == "ground") {
			isGrounded = true;
			canJump = true;
			isJumping = false;
			gravityModifier = 0.75f;
		}

		if (col.gameObject.tag == "LadderBottom") {
			if (!isJumping) {
				
				canDown = false;

				canLeft = true;
				canRight = true;
			}
		}

		if (col.gameObject.tag == "LadderBottomEnter") {
			if (!isJumping) {
				canClimb = true;
				canUp = true;
				canJump = true;
				isClimbing = false;
			}
		}

		if (col.gameObject.tag == "LadderMiddle" && isClimbing == true) {
				canClimb = true;
				canUp = true;
				canDown = true;
				canJump = false;
				isClimbing = true;
			
		}
		if (col.gameObject.tag == "LadderTopExit") {
			canClimb = true;
			canDown = true;
			canUp = false;
			canLeft = true;
			canRight = true;
			isGrounded = true;
			canJump = true;
			isClimbing = false;

		}


		if (col.gameObject.tag == "miniLadderTopExit") {
			canClimb = true;
			canDown = true;
			canUp = false;
		}


		if (col.gameObject.tag == "LadderTop") {
			canClimb = true;
			canDown = true;
			isGrounded = true;

		}
			

	//Upon Entering Win Trigger
		if(col.gameObject.tag == "Win"){
			//trigger animal control animation
			//load next scene
			SceneManager.LoadScene (SceneManager.GetActiveScene().buildIndex + 1);
		}

	}

	public void OnTriggerStay2d(Collider2D col){
		if (col.gameObject.tag == "LadderTop") {
			canClimb = true;
			canDown = true;
			isGrounded = true;

		}
		if (col.gameObject.tag == "LadderBottom") {
			canClimb = true;
			canUp = true;
			isGrounded = true;

		}
	}


	//exit the trigger
	public void OnTriggerExit2D(Collider2D col)
	{
		if (col.gameObject.tag == "ground") {
			isGrounded = false;
			canJump = false;
		}
		if (col.gameObject.tag == "LadderTop") {
			//isClimbing = false;
			canDown = true;
			canUp = true;
		}
		if (col.gameObject.tag == "LadderBottomEnter") {
			//isClimbing = false;
		}

		if (col.gameObject.tag == "LadderMaster") {
			canClimb = false;
			canUp = false;
			canDown = false;
			canLeft = true;
			canRight = true;
			gravityModifier = 0.75f;
			isClimbing = false;
		}

		if (col.gameObject.tag == "LadderBottom") {
			canDown = true;
		}
	}
		

	IEnumerator Death (){
		yield return new WaitForSeconds (5);
		Lives.CurLives--;
		if (Lives.CurLives > 0) {
			SceneManager.LoadScene (SceneManager.GetActiveScene ().name);
		} else {
			SceneManager.LoadScene (0);
		}
	}

	IEnumerator Laser(){
		isLaser = true;
		float timer = 0f;
		while (timer < laserTime) {
			timer += Time.deltaTime;
		}
		yield return null;

	}

	void Movement(Vector2 move, bool yMovement)
	{
		float distance = move.magnitude;

		if (distance > minMoveDistance) 
		{
			int count = rb2d.Cast (move, contactFilter, hitBuffer, distance + shellRadius);
			hitBufferList.Clear ();
			for (int i = 0; i < count; i++) {
				hitBufferList.Add (hitBuffer [i]);
			}

			for (int i = 0; i < hitBufferList.Count; i++) 
			{
				Vector2 currentNormal = hitBufferList [i].normal;
				if (currentNormal.y > minGroundNormalY) 
				{
					if (yMovement) 
					{
						
						groundNormal = currentNormal;
						currentNormal.x = 0;
					}
				}

				float projection = Vector2.Dot (velocity, currentNormal);
				if (projection < 0) 
				{
					velocity = velocity - projection * currentNormal;
				}

				float modifiedDistance = hitBufferList [i].distance - shellRadius;
				distance = modifiedDistance < distance ? modifiedDistance : distance;
			}


		}

		rb2d.position = rb2d.position + move.normalized * distance;

	}

}
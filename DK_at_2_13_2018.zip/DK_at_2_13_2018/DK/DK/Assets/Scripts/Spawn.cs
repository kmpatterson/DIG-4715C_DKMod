﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Spawn : MonoBehaviour {

	public GameObject spawnPoint;
	public GameObject playerPrefab;

	// Use this for initialization
	void Start () {
		spawnPoint = GameObject.Find ("spawnPlayer");
		GameObject Player = (GameObject)Instantiate (playerPrefab, spawnPoint.transform.position, spawnPoint.transform.rotation);
	}
	
	// Update is called once per frame
	void Update () {
		
	}
}

﻿using UnityEngine;
using System.Collections;

public class Waypoint : MonoBehaviour
{
	public float waitSeconds = 0;
	public float speedOut = 0;
}

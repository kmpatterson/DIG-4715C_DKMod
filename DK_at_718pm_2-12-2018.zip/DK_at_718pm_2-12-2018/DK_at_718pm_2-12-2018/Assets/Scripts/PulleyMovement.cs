﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PulleyMovement : MonoBehaviour {

	var pulley: GameObject;
	bool goingUp = false;
	float upSpeed = 1;

	void OnTriggerEnter(Collider collider)
	{
		if (collider.gameObject.name == "Player") 
		{
			goingUp = true;
			PulleyMovement.animation.Play ("pulley");
		}
	}

	void OnTriggerExit ()
	{
		animation.Pause ();
	}
		

	// Use this for initialization
	void Start () {
		animation.Stop ();
	}
	
	// Update is called once per frame
	void Update () {

		if (goingUp) 
		{
			upSpeed += Time.deltaTime / 10;
			transform.position = new Vector3 (transform.position.x,
				transform.position.y - upSpeed,
				transform.position.z);
		}

	}
}

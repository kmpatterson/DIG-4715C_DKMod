﻿using UnityEngine;
using System.Collections;

public class Lives
{
	private static int m_InitialLives = 2;
	private static int m_CurLives;

	static Lives(){
		m_CurLives = PlayerPrefs.GetInt ("lives", m_InitialLives);
	}

	public static int CurLives
	{
		get { return m_CurLives; }
		set{
			m_CurLives = Mathf.Max (0, value);
			PlayerPrefs.SetInt ("lives", m_CurLives);

		}

	}


}
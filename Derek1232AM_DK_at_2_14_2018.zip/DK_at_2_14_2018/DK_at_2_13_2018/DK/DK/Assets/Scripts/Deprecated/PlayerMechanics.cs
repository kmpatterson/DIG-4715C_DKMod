﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class PlayerMechanics : MonoBehaviour {

	public enum playerState {dead, grounded, airborn, climbing};

	public GameObject player;
	public float climbSpeed;
	public float walkSpeed;
	public bool climb;

	void start(){
		player = GameObject.FindWithTag("Player");
	}

	//Update is called once per frame
	void Update (){
		if (Input.GetKey ("s")) {
			Debug.Log ("I'm Climbing Down");
			muhFall ();
		}
		if (Input.GetKey ("d")) {
			Debug.Log ("I'm going right");
			goRight ();
		}

		if (Input.GetKey ("a")) {
			Debug.Log ("I'm going left");
			goLeft ();
		}

		if(Input.GetKey("w")){
			if (climb == true) {
				muhClimb ();
			}
			Debug.Log("I'm Climbing Up");
		}


		if (Input.GetKey ("space")) {
			Debug.Log ("I'm Jumping");
			jump ();
		}

	}



	void muhClimb (){
		transform.position += new Vector3 (0, climbSpeed, 0);
			}

	void muhFall(){
		transform.position -= new Vector3 (0, climbSpeed, 0);
			}

	void goRight(){
		transform.position += new Vector3 (walkSpeed, 0, 0);
			}

	void goLeft(){
		transform.position -= new Vector3 (walkSpeed, 0, 0);
			}
	void jump(){
		
			}
}
